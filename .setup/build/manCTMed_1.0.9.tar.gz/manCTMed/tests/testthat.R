library(testthat)
library(manCTMed)

test_check("manCTMed")
